#include <stdio.h>
#include "matrix.h"

int main() {
    printf("\nWelcome to Matrix calculation\npowered by JakoError\n");
    matrixMain();
    return 0;
}
