#ifndef HEADER_FILE
#define HEADER_FILE

void stack_underflow();
void stack_overflow();
void make_empty(void);
bool is_empty(void);
bool is_full(void);
void push(int i);
int pop(void);
int partition(int left, int right);
void q_sort_stack();

#endif
