#ifndef HEADER_FILE
#define HEADER_FILE
#include <stdbool.h>

typedef long long LL ;

int add_calculate(char str[],int len,int * Currentcnt);
int fnd_formula_split (char str[],int len) ;
void formula_split (char **p ,char* str,int len);
int get_cal_ans (char *p1,char *p2,int len1,int len2,int *ans);
void reverse(char *,int );

#endif
